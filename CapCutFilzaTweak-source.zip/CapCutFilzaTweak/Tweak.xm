#import <UIKit/UIKit.h>
#import <objc/runtime.h>

// Experimental: opens Filza when the Library/Biblioteca tab is selected.
// The tab title and index are app-version/localization dependent.

static BOOL CFTitleMatches(NSString *title) {
    if (![title isKindOfClass:[NSString class]]) return NO;
    NSString *s = title.lowercaseString;
    return [s containsString:@"biblioteca"] ||
           [s isEqualToString:@"library"] ||
           [s containsString:@"library"];
}

%hook UITabBarController

- (void)setSelectedIndex:(NSUInteger)index {
    %orig;

    NSArray<UITabBarItem *> *items = self.tabBar.items;
    if (index >= items.count) return;
    if (!CFTitleMatches(items[index].title)) return;

    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.35 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        NSURL *url = [NSURL URLWithString:@"filza://"];
        UIApplication *app = UIApplication.sharedApplication;
        if ([app canOpenURL:url]) {
            [app openURL:url options:@{} completionHandler:nil];
        }
    });
}

%end
