# CapCut Filza Tab (experimental)

This is a Theos tweak project targeting arm64 / iOS 15. It attempts to open `filza://` when a `UITabBarController` tab item titled `Biblioteca` or `Library` is selected.

## Important limitations
- This is source code, not a prebuilt or tested dylib.
- The CapCut IPA supplied in the conversation must be inspected on-device to confirm the Library tab is implemented by `UITabBarController` and exposes one of the expected titles. Some CapCut builds use a custom tab UI, in which case this hook will not fire.
- TrollFools injection compatibility and the Filza URL scheme must be tested on the target device.
- The tweak does not alter or bypass CapCut Pro entitlements or subscriptions.

## Build
Push these files to a GitHub repository, then run the `Build CapCut Filza dylib` workflow from the Actions tab. Download the workflow artifact and inspect its contents. Do not inject it unless the build succeeds and you have verified compatibility.
